using UnityEngine;

public class EnemyIdleState : EnemyBaseState
{
    private readonly int LocomotionBlendTreeHash = Animator.StringToHash("Walking");
    private readonly int SpeedHash = Animator.StringToHash("Speed");

    private const float CrossFadeDuration = 0.1f;
    private const float AnimatorDampTime = 0.1f;

    public EnemyIdleState(EnemyStateMachine stateMachine) : base(stateMachine) { }

    public override void Enter()
    {
        stateMachine.Animator.CrossFadeInFixedTime(LocomotionBlendTreeHash, CrossFadeDuration);
        if (stateMachine.Agent != null)
        {
            stateMachine.Agent.stoppingDistance = 0f;
        }
        // If no patrol points, we just idle in place.
    }

    public override void Tick(float deltaTime)
    {
        if (IsInChaseRange())
        {
            stateMachine.SwitchState(new EnemyChasingState(stateMachine));
            return;
        }

        if (stateMachine.PatrolPoints == null || stateMachine.PatrolPoints.Length == 0)
        {
            // Idle on spot
            stateMachine.Animator.SetFloat(SpeedHash, 0f, AnimatorDampTime, deltaTime);
            Move(deltaTime);
            return;
        }

        // PATROL
        Transform target = stateMachine.PatrolPoints[Mathf.Clamp(stateMachine.PatrolIndex, 0, stateMachine.PatrolPoints.Length - 1)];
        if (target == null)
        {
            stateMachine.Animator.SetFloat(SpeedHash, 0f, AnimatorDampTime, deltaTime);
            return;
        }

        Vector3 to = target.position - stateMachine.transform.position;
        float sqr = to.sqrMagnitude;
        bool atPoint = sqr <= 0.25f * 0.25f;

        if (atPoint)
        {
            if (Time.time - stateMachine.LastAtPointTime > stateMachine.PatrolWaitTime)
            {
                stateMachine.LastAtPointTime = Time.time;
                AdvancePatrolIndex();
            }
            stateMachine.Animator.SetFloat(SpeedHash, 0f, AnimatorDampTime, deltaTime);
            Move(deltaTime);
            return;
        }

        // Move towards patrol target using NavMeshAgent steering
        if (stateMachine.Agent != null)
        {
            stateMachine.Agent.destination = target.position;
            Vector3 desired = stateMachine.Agent.desiredVelocity.normalized * stateMachine.MovementSpeed * stateMachine.PatrolSpeedMultiplier;
            Move(desired, deltaTime);
            stateMachine.Agent.velocity = stateMachine.Controller.velocity;
        }
        else
        {
            Vector3 dir = to.normalized * stateMachine.MovementSpeed * stateMachine.PatrolSpeedMultiplier;
            Move(dir, deltaTime);
        }

        // Face movement direction instead of the player
        Vector3 flat = new Vector3(to.x, 0f, to.z);
        if (flat.sqrMagnitude > 0.0001f)
        {
            Quaternion look = Quaternion.LookRotation(flat);
            stateMachine.transform.rotation = Quaternion.Slerp(stateMachine.transform.rotation, look, 0.2f);
        }

        stateMachine.Animator.SetFloat(SpeedHash, 1f * stateMachine.PatrolSpeedMultiplier, AnimatorDampTime, deltaTime);
    }

    private void AdvancePatrolIndex()
    {
        if (stateMachine.PatrolLoop)
        {
            stateMachine.PatrolIndex = (stateMachine.PatrolIndex + 1) % stateMachine.PatrolPoints.Length;
        }
        else
        {
            // Ping-pong
            int next = stateMachine.PatrolIndex + stateMachine.PatrolDirection;
            if (next < 0 || next >= stateMachine.PatrolPoints.Length)
            {
                stateMachine.PatrolDirection *= -1;
                next = Mathf.Clamp(stateMachine.PatrolIndex + stateMachine.PatrolDirection, 0, stateMachine.PatrolPoints.Length - 1);
            }
            stateMachine.PatrolIndex = next;
        }
    }

    public override void Exit() { }
}
