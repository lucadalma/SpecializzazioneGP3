using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MenuManager : MonoBehaviour
{

    [SerializeField] GameObject pauseCanvas;

    [SerializeField] GameObject healthCanvas;

    [SerializeField] GameObject endGameCanvas;

    [SerializeField] List<IntVariable> intVariables;

    [SerializeField] List<FloatVariable> floatVariables;

    [SerializeField] Health playerHealth;

    [SerializeField] Health enemyHealth;


    private void OnEnable()
    {
        if (playerHealth && enemyHealth)
        {
            playerHealth.OnDie += EndGame;
            enemyHealth.OnDie += EndGame;
        }
    }

    private void OnDisable()
    {
        if (playerHealth && enemyHealth)
        {
            playerHealth.OnDie -= EndGame;
            enemyHealth.OnDie -= EndGame;
        }
    }

    public void StartApplication()
    {
        SceneManager.LoadScene("TestScene", LoadSceneMode.Single);
    }


    public void QuitApplication()
    {
        Application.Quit();
    }


    private void Update()
    {
        if (!endGameCanvas)
        {
            if (Input.GetKeyDown(KeyCode.Escape))
            {
                if (pauseCanvas.activeSelf)
                {
                    Time.timeScale = 1;
                    pauseCanvas.SetActive(false);
                    healthCanvas.SetActive(true);
                }
                else
                {
                    Time.timeScale = 0;
                    pauseCanvas.SetActive(true);
                    healthCanvas.SetActive(false);
                }
            }
        }
    }

    public void ReloadScene()
    {
        foreach (IntVariable variable in intVariables)
        {
            variable.Value = 0;
        }

        foreach (FloatVariable variable in floatVariables)
        {
            variable.Value = 0f;
        }

        SceneManager.LoadScene("TestScene", LoadSceneMode.Single);

    }

    public void EndGame()
    {
        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;

        endGameCanvas.SetActive(true);

        pauseCanvas.SetActive(false);

        healthCanvas.SetActive(false);

    }

}
